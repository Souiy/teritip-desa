# Before Run, Make Sure Already Install Requirements & Settings Proxy On local_proxies.txt
```
You Can Manual Download As Zip File
OR
git clone https://github.com/ylasgamers/getgrass.git
```
```
cd getgrass
```
- Please Choose :
- Lite 1x | Node 1.25x | Desktop 2x
- Lite Version With Proxy = localgrasslite.py
- Lite Version Without Proxy = localgrasslite_noproxy.py
- Lite Version Auto Proxy = localgrasslite_autoproxy.py
- Node Version With Proxy = localgrassnode.py
- Node Version Without Proxy = localgrassnode_noproxy.py
- Node Version Auto Proxy = localgrassnode_autoproxy.py
- Desktop Version With Proxy = localgrassdesktop.py
- Desktop Version Without Proxy = localgrassdesktop_noproxy.py
- Desktop Version Auto Proxy = localgrassdesktop_autoproxy.py
```
python localgrasslite.py
python localgrassnode.py
python localgrassdesktop.py
python localgrasslite_noproxy.py
python localgrassnode_noproxy.py
python localgrassdesktop_noproxy.py
python localgrasslite_autoproxy.py
python localgrassnode_autoproxy.py
python localgrassdesktop_autoproxy.py
OR
python3 localgrasslite.py
python3 localgrassnode.py
python3 localgrassdesktop.py
python3 localgrasslite_noproxy.py
python3 localgrassnode_noproxy.py
python3 localgrassdesktop_noproxy.py
python3 localgrasslite_autoproxy.py
python3 localgrassnode_autoproxy.py
python3 localgrassdesktop_autoproxy.py
```
